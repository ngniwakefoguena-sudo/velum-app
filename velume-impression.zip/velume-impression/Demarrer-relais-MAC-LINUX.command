#!/bin/bash
cd "$(dirname "$0")"
# Facultatif : export VELUME_TOKEN="mon-jeton-secret"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js n'est pas installé. Installez la version LTS : https://nodejs.org"
  read -p "Appuyez sur Entrée..." ; exit 1
fi
node velume-relay.js
