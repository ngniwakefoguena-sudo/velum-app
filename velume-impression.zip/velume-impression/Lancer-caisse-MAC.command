#!/bin/bash
URL="https://velum-app-nds22.vercel.app"
open -na "Google Chrome" --args --kiosk-printing --app="$URL" 2>/dev/null || open -na "Microsoft Edge" --args --kiosk-printing --app="$URL"
