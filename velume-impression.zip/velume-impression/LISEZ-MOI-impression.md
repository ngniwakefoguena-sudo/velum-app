# VÉLUME — imprimer les tickets et ouvrir le tiroir-caisse

VÉLUME est une page web : un navigateur n'a pas le droit de parler directement à une imprimante réseau ou au tiroir-caisse.
Ce dossier contient donc un **petit relais** à lancer sur l'ordinateur de la caisse (Windows, Mac ou Linux).

## Quelle solution choisir ?

| Votre matériel | Solution |
|---|---|
| Imprimante de tickets **USB** branchée à un PC (avec son pilote installé) | **Imprimante installée** (relais) |
| Imprimante de tickets **Wi-Fi / Ethernet** (a une adresse IP, port 9100) | **Réseau** (relais) |
| Imprimante classique (A4) ou impression simple | **Navigateur** (aucun relais) |
| Tablette / téléphone | **Navigateur** (impression Android / AirPrint) — le relais ne marche pas sur tablette |
| Tiroir-caisse relié à l'imprimante de tickets (câble RJ11) | Cochez « Ouvre le tiroir-caisse » sur l'imprimante |

## 1. Installer le relais (une seule fois)
1. Installez **Node.js (version LTS)** : https://nodejs.org
2. Copiez ce dossier sur l'ordinateur de la caisse.
3. **Windows :** double-clic sur `Demarrer-relais-WINDOWS.bat`.  
   **Mac / Linux :** double-clic (ou terminal) sur `Demarrer-relais-MAC-LINUX.command`.
4. Une fenêtre noire s'ouvre : « Écoute sur http://127.0.0.1:9101 ». **Laissez-la ouverte** pendant le service.

*Démarrage automatique (Windows) :* touches `Windows + R`, tapez `shell:startup`, et glissez-y un raccourci vers `Demarrer-relais-WINDOWS.bat`.

## 2. Déclarer l'imprimante dans VÉLUME
Point de Vente › Configuration › Imprimantes › Nouveau.

**Imprimante installée sur l'ordinateur (USB) :** Connexion = « Imprimante installée sur l'ordinateur — via le relais » ; *Nom de l'imprimante* = exactement le nom affiché dans Windows (Paramètres › Imprimantes). Largeur : 58 ou 80 mm.

**Imprimante réseau :** Connexion = « Réseau (adresse IP) — via le relais » ; *Adresse IP* de l'imprimante (imprimez son auto-test pour la lire) ; *Port* 9100.

Puis :
- **Tester le relais** (bouton dans la fiche) : doit afficher « Relais OK ».
- **Imprimer un ticket de test**.
- Cochez **Imprime le ticket client à chaque encaissement** pour le ticket de caisse.
- Cochez **Ouvre le tiroir-caisse** si le tiroir est branché à cette imprimante ; bouton **Tester le tiroir-caisse**.
- Les tickets **cuisine / bar** partent tout seuls vers les imprimantes liées à un écran de préparation (option « Imprimer automatiquement »).

## 3. Impression sans fenêtre (mode Navigateur)
Utilisez `Lancer-caisse-WINDOWS.bat` (ou `Lancer-caisse-MAC.command`) pour ouvrir VÉLUME avec `--kiosk-printing` :
l'impression part directement sur l'imprimante par défaut, sans confirmation. Réglez l'imprimante de tickets comme imprimante par défaut.

## Sécurité (recommandé)
Le relais n'écoute que sur l'ordinateur local. Pour qu'aucun autre site ne puisse l'utiliser, définissez un jeton :
dans le `.bat`, retirez `rem` devant `set VELUME_TOKEN=...`, choisissez un mot secret, puis recopiez-le dans *Jeton du relais* de la fiche imprimante.
Vous pouvez aussi limiter au site de VÉLUME : `set VELUME_ORIGINS=https://velum-app-nds22.vercel.app`.

## Limites à connaître
- Le relais doit tourner sur l'ordinateur où est branchée l'imprimante. Chrome / Edge / Firefox fonctionnent ; **Safari (Mac, iPad, iPhone) bloque** l'accès au relais : utilisez le mode Navigateur.
- La première fois, Chrome peut demander l'autorisation « accéder aux appareils du réseau local » : acceptez.
- Test réalisé sur une imprimante simulée (réseau) : le chemin **Windows « imprimante installée »** et le **tiroir-caisse réel** n'ont pas pu être testés sur du vrai matériel. Si un modèle réagit mal (caractères, coupe, tiroir), dites-moi la marque et le modèle.
- Les caractères accentués sont imprimés sans accent (compatible avec toutes les imprimantes).
- Pas de lien avec un logiciel de caisse externe : VÉLUME est la caisse.
