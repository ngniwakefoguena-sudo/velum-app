#!/usr/bin/env node
/* VÉLUME — relais d'impression (Windows, macOS, Linux). Aucune dépendance : Node.js 16 ou plus.
 * Il reçoit les tickets depuis VÉLUME (navigateur) et les envoie :
 *   - à une imprimante réseau (adresse IP, port 9100, ESC/POS) ;
 *   - à une imprimante installée sur cet ordinateur (USB, Bluetooth appairé, partagée...).
 * Il écoute uniquement sur cet ordinateur (127.0.0.1).
 *
 * Lancer :  node velume-relay.js
 * Options (variables d'environnement) :
 *   VELUME_PORT=9101        port du relais
 *   VELUME_TOKEN=secret     jeton à recopier dans la fiche imprimante de VÉLUME (recommandé)
 *   VELUME_ORIGINS=https://velum-app-nds22.vercel.app   limite les sites autorisés (séparés par des virgules)
 */
'use strict';
const http=require('http'),net=require('net'),os=require('os'),fs=require('fs'),path=require('path');
const {execFile}=require('child_process');
const PORT=+(process.env.VELUME_PORT||process.argv[2]||9101);
const TOKEN=process.env.VELUME_TOKEN||'';
const ORIGINS=(process.env.VELUME_ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean);
const VERSION='1.0';
const IS_WIN=process.platform==='win32';
const log=(...a)=>console.log(new Date().toLocaleTimeString(),...a);

function cors(req,res){
  const o=req.headers.origin||'';
  const ok=!ORIGINS.length||ORIGINS.includes(o);
  if(o&&ok)res.setHeader('Access-Control-Allow-Origin',o);
  res.setHeader('Vary','Origin');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers','Content-Type,X-Velume-Token');
  res.setHeader('Access-Control-Allow-Private-Network','true');
  res.setHeader('Access-Control-Max-Age','600');
  return ok;
}
const send=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(obj))};

function tcpPrint(host,port,buf){
  return new Promise((resolve,reject)=>{
    const s=net.connect({host,port,timeout:6000});
    s.on('connect',()=>{s.write(buf,()=>{s.end()})});
    s.on('close',()=>resolve());
    s.on('timeout',()=>{s.destroy();reject(new Error('Imprimante injoignable ('+host+':'+port+')'))});
    s.on('error',e=>reject(new Error('Imprimante injoignable ('+host+':'+port+') : '+e.message)));
  });
}

const PS_RAW=`
param([string]$Printer,[string]$File)
Add-Type -TypeDefinition @"
using System;using System.Runtime.InteropServices;
public class RawPrn{
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] public class DOCINFO{[MarshalAs(UnmanagedType.LPWStr)]public string d;[MarshalAs(UnmanagedType.LPWStr)]public string o;[MarshalAs(UnmanagedType.LPWStr)]public string t;}
 [DllImport("winspool.drv",CharSet=CharSet.Unicode,SetLastError=true)] public static extern bool OpenPrinter(string n,out IntPtr h,IntPtr d);
 [DllImport("winspool.drv",SetLastError=true)] public static extern bool ClosePrinter(IntPtr h);
 [DllImport("winspool.drv",CharSet=CharSet.Unicode,SetLastError=true)] public static extern bool StartDocPrinter(IntPtr h,int l,[In] DOCINFO di);
 [DllImport("winspool.drv",SetLastError=true)] public static extern bool EndDocPrinter(IntPtr h);
 [DllImport("winspool.drv",SetLastError=true)] public static extern bool StartPagePrinter(IntPtr h);
 [DllImport("winspool.drv",SetLastError=true)] public static extern bool EndPagePrinter(IntPtr h);
 [DllImport("winspool.drv",SetLastError=true)] public static extern bool WritePrinter(IntPtr h,IntPtr b,int c,out int w);
 public static void Send(string name,byte[] data){
  IntPtr h;if(!OpenPrinter(name,out h,IntPtr.Zero))throw new Exception("Imprimante introuvable : "+name);
  var di=new DOCINFO();di.d="VELUME";di.o=null;di.t="RAW";
  try{ if(!StartDocPrinter(h,1,di))throw new Exception("StartDoc");StartPagePrinter(h);
   IntPtr p=Marshal.AllocCoTaskMem(data.Length);Marshal.Copy(data,0,p,data.Length);int w;WritePrinter(h,p,data.Length,out w);Marshal.FreeCoTaskMem(p);
   EndPagePrinter(h);EndDocPrinter(h);} finally{ClosePrinter(h);}
 }}
"@
[RawPrn]::Send($Printer,[System.IO.File]::ReadAllBytes($File))
`;
let psFile=null;
function sysPrint(name,buf){
  return new Promise((resolve,reject)=>{
    if(!name)return reject(new Error('Nom d\'imprimante manquant'));
    const tmp=path.join(os.tmpdir(),'velume-'+Date.now()+'-'+Math.random().toString(36).slice(2)+'.bin');
    fs.writeFileSync(tmp,buf);
    const done=e=>{try{fs.unlinkSync(tmp)}catch(x){}e?reject(e):resolve()};
    if(IS_WIN){
      if(!psFile){psFile=path.join(os.tmpdir(),'velume-raw.ps1');fs.writeFileSync(psFile,PS_RAW)}
      execFile('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',psFile,'-Printer',name,'-File',tmp],{timeout:20000},(e,so,se)=>done(e?new Error((se||e.message).toString().split('\n')[0]):null));
    }else{
      execFile('lp',['-d',name,'-o','raw',tmp],{timeout:20000},(e,so,se)=>done(e?new Error((e.code==='ENOENT'?'Commande d’impression « lp » introuvable sur cet ordinateur':(se||e.message).toString().trim())):null));
    }
  });
}
function listPrinters(){
  return new Promise(resolve=>{
    if(IS_WIN)execFile('powershell.exe',['-NoProfile','-Command','Get-Printer | Select-Object -ExpandProperty Name'],{timeout:10000},(e,so)=>resolve(e?[]:String(so).split(/\r?\n/).map(s=>s.trim()).filter(Boolean)));
    else execFile('lpstat',['-e'],{timeout:8000},(e,so)=>resolve(e?[]:String(so).split(/\r?\n/).map(s=>s.trim()).filter(Boolean)));
  });
}

const server=http.createServer((req,res)=>{
  const ok=cors(req,res);
  if(req.method==='OPTIONS'){res.writeHead(ok?204:403);return res.end()}
  if(!ok)return send(res,403,{ok:false,error:'Site non autorisé'});
  if(TOKEN&&req.headers['x-velume-token']!==TOKEN)return send(res,401,{ok:false,error:'Jeton incorrect'});
  const url=(req.url||'').split('?')[0];
  if(req.method==='GET'&&url==='/ping')return listPrinters().then(p=>send(res,200,{ok:true,relay:'velume',version:VERSION,os:process.platform,printers:p}));
  if(req.method==='POST'&&url==='/print'){
    let body='';req.on('data',c=>{body+=c;if(body.length>2e6)req.destroy()});
    req.on('end',async()=>{
      try{
        const j=JSON.parse(body||'{}');const buf=Buffer.from(String(j.data||''),'base64');
        if(!buf.length)throw new Error('Ticket vide');
        if(j.mode==='lan')await tcpPrint(String(j.host||''),+j.port||9100,buf);
        else if(j.mode==='sys')await sysPrint(String(j.printer||''),buf);
        else throw new Error('Mode inconnu');
        log('OK',j.mode,j.mode==='lan'?j.host:j.printer,buf.length+' octets');send(res,200,{ok:true});
      }catch(e){log('ERREUR',e.message);send(res,500,{ok:false,error:e.message})}
    });return;
  }
  send(res,404,{ok:false,error:'Introuvable'});
});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Le port '+PORT+' est déjà utilisé : le relais tourne peut-être déjà.':e.message);process.exit(1)});
server.listen(PORT,'127.0.0.1',()=>{
  console.log('\n  VÉLUME — relais d\'impression v'+VERSION+'\n  Écoute sur http://127.0.0.1:'+PORT+'  ('+process.platform+')'+(TOKEN?'  [jeton activé]':'  [sans jeton]')+(ORIGINS.length?'\n  Sites autorisés : '+ORIGINS.join(', '):'')+'\n  Laissez cette fenêtre ouverte pendant le service.\n');
});
