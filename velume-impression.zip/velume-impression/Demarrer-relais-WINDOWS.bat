@echo off
chcp 65001 >nul
title VELUME - relais d'impression
cd /d "%~dp0"
rem Facultatif : decommentez et choisissez un jeton, puis recopiez-le dans la fiche imprimante de VELUME
rem set VELUME_TOKEN=mon-jeton-secret
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js n'est pas installe. Telechargez la version LTS sur https://nodejs.org puis relancez ce fichier.
  pause
  exit /b
)
node velume-relay.js
pause
