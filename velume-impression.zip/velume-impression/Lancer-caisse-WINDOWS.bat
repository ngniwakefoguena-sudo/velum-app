@echo off
rem Ouvre VELUME en plein ecran avec l'impression directe (sans fenetre de confirmation).
set URL=https://velum-app-nds22.vercel.app
start "" chrome --kiosk-printing --app=%URL% 2>nul || start "" msedge --kiosk-printing --app=%URL%
